import org.apache.spark.sql.{Encoders, SparkSession}
import java.text.SimpleDateFormat
import java.util.Locale

case class TradgVnRltdAttrbts(AdmssnApprvlDtByIssr: String, FrstTradDt: String, Id: String, IssrReq: String, ReqForAdmssnDt: String, TermntnDt: String)

case class PblctnPrd(FrDt: String)

case class TechAttrbts(PblctnPrd: PblctnPrd, RlvntCmptntAuthrty: String)

case class FinInstrmGnlAttrbts(ClssfctnTp: Option[String], CmmdtyDerivInd: Option[Boolean], FullNm: Option[String], Id: Option[String], NtnlCcy: Option[String], ShrtNm: Option[String])

case class common(
                   FinInstrmGnlAttrbts: FinInstrmGnlAttrbts,
                   Issr: String,
                   TechAttrbts: TechAttrbts,
                   TradgVnRltdAttrbts: Option[TradgVnRltdAttrbts])

case class FinInstrm(CancRcrd: common, ModfdRcrd: common, NewRcrd: common, TermntdRcrd: common)

object Main {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("Datasets")
      .config("spark.master", "local")
      .getOrCreate()
    import spark.implicits._

    val df = spark.read
      .format("com.databricks.spark.xml")
      .option("mode", "DROPMALFORMED")
      .option("rootTag", "FinInstrmRptgRefDataDltaRpt")
      .option("rowTag", "FinInstrm").schema(Encoders.product[FinInstrm].schema)
      .load("src/main/resources/FIRDS_DLTINS_PUBLI_01Z01-000001_22.xml")

    df.printSchema()

    val rdf = df.as[FinInstrm].map(x => {

      def rebuild[T <: common](t: T) = {

        if (t == null) t else {
          t.TradgVnRltdAttrbts match {
            case Some(i) => {

              def tryParse(s: String): String = {
                try {
                  new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ROOT).parse(s.replace("Z", "")).getTime.toString
                }
                catch {
                  case e: Exception => s
                }
              }

              val stub = i.copy(
                AdmssnApprvlDtByIssr = tryParse(i.AdmssnApprvlDtByIssr),
                FrstTradDt = tryParse(i.FrstTradDt),
                ReqForAdmssnDt = tryParse(i.ReqForAdmssnDt),
                TermntnDt = tryParse(i.TermntnDt)
              )
              t.copy(TradgVnRltdAttrbts = Some(stub))
            }
            case None => t
          }
        }
      }

      FinInstrm(
        rebuild(x.CancRcrd),
        rebuild(x.ModfdRcrd),
        rebuild(x.NewRcrd),
        rebuild(x.TermntdRcrd))
    })


    //    df.withColumn("ModfdRcrd.TradgVnRltdAttrbts.AdmssnApprvlDtByIssr", unix_timestamp($"ModfdRcrd.TradgVnRltdAttrbts.AdmssnApprvlDtByIssr".cast(TimestampType)))
    //      .show(10, false)


    //    println(df.schema)
    //    df.show(10, false);

        rdf.repartition(1).write.format("com.databricks.spark.xml")
          .option("rootTag", "FinInstrmRptgRefDataDltaRpt")
          .option("rowTag", "FinInstrm")
          .mode("overwrite")
          .save("src/main/resources/out/output.xml")
    //df.printSchema()
  }
}